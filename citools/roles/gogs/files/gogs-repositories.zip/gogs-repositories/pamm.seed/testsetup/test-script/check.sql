SELECT 'PASSED'
FROM PROJECT
WHERE project_code = 'e2e-test1234'
AND title = 'Test Project 1'
AND summary = 'e2e tests';