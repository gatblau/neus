DELETE FROM project_user;
DELETE FROM project;