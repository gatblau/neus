package pamm.infrastructure.security.authentication;

public enum TokenStatus {VALID, INVALID, EXPIRED}

