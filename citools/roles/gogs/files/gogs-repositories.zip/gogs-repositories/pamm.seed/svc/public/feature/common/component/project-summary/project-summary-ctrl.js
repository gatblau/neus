"use strict";

angular.module("pamm").controller("projectSummaryCtrl", ["$scope", "$log", "userContext",
    function ($scope, $log, userContext) {
        var vm = this;
        $log.info("projectSummaryCtrl: instantiated");
    }]);
