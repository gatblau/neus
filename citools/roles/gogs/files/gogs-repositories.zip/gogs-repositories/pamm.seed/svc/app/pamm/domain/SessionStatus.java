package pamm.domain;

public enum SessionStatus {NEW, REMOVED};