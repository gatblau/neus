package util.json.play;

public class JSONHelperTestClass
{
    private String testProp1;

    private String testProp2;

    public JSONHelperTestClass()
    {
    }

    public JSONHelperTestClass(String testProp1, String testProp2)
    {
        this.testProp1 = testProp1;

        this.testProp2 = testProp2;
    }

    public String getTestProp1()
    {
        return testProp1;
    }

    public String getTestProp2()
    {
        return testProp2;
    }
}
