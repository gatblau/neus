angular.module('app', ["ui.router", "dal", "repository", "securityManager", "util", "sse"]);
