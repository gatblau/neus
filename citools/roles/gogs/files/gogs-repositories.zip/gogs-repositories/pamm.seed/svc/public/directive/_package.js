$$include.script("match.js");
$$include.script("lowercase.js");
$$include.script("uppercase.js");
$$include.script("before.js");
$$include.script("autofocus.js");
