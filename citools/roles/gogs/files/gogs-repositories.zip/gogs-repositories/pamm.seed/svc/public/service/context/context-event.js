"use strict";

angular.module("pamm").constant("contextEvent", {
    CLEAR_CONTEXT: "CLEAR_CONTEXT"
});