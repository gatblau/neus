"use strict";

angular.module("pamm").controller("homeCtrl", ["$state", "$log",
    function ($state, $log) {
        var vm = this;
    }]);
