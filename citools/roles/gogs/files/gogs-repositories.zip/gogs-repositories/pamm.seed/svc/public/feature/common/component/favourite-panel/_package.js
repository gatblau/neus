$$include.script("favourite-panel-ctrl.js");
$$include.script("favourite-panel.js");
$$include.less("favourite-panel.less");
