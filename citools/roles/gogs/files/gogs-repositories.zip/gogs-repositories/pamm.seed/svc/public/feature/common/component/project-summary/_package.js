$$include.script("project-summary-ctrl.js");
$$include.script("project-summary.js");
$$include.less("project-summary.less");
