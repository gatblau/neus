activator "testsetup/run 9001"
