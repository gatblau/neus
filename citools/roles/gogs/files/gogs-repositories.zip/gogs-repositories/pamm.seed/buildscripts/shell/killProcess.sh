kill $(lsof -i:$1 -t)
