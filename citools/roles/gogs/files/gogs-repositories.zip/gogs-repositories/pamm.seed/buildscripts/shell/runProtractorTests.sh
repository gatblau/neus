node_modules/.bin/protractor svc/test/webapp/e2e_tests/conf.js
