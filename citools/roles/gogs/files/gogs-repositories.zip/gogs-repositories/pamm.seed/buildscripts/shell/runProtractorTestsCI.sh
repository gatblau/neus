node_modules/.bin/protractor svc/test/webapp/protractor_jasmine/e2e/conf-ci.js
