lsof -i -t
