javaw -cp ~/.ivy2/cache/com.h2database/h2/jars/h2-1.4.190.jar org.h2.tools.Server -tcp -tcpAllowOthers
