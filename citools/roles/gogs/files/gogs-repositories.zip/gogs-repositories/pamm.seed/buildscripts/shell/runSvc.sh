activator "svc/run 9000"
