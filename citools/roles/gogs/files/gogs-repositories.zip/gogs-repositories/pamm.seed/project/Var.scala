object Var {
  val APP_URI = "http://pamm.gatblau.org"
  val APP_ORG = "gatblau.org"
  val APP_ORG_HOME = "http://gatblau.org/pamm"
  val APP_DESC = "A template project for Web Applications using Play, AngularJS, MariaDB and MongoDB."
  val APP_YEAR = 2015
  val APP_LIC_NAME = "Apache 2"
  val APP_LIC_URI = "http://www.apache.org/licenses/LICENSE-2.0.txt"
}