PAMM: Architecture
=

![](./img/architecture.png)

