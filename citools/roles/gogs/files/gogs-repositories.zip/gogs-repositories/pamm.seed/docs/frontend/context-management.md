PAMM: Front-end - Context Management
=
<img src="img/context-example-1.png" width="50%"/>
<br/>
<img src="img/context-example-2.png" width="75%"/>
<br/>
<img src="img/feature.png" width="75%"/>
<br/>
<img src="img/context-tree.png" width="75%"/>
<br/>